# 🛡️ SIEM Lab — Wazuh + ELK Stack

> Déploiement d'un SIEM open source complet pour la centralisation, corrélation et visualisation de logs en environnement virtualisé.

**Auteur :** Ali ADOUM MAHAMAT  
**GitHub :** [@AMA972](https://github.com/AMA972)  
**Localisation :** Montpellier, France  
**Stack :** Wazuh 4.x · Elasticsearch · Kibana · Ubuntu Server 22.04

---

## 📋 Table des matières

- [Objectifs](#-objectifs)
- [Architecture](#-architecture)
- [Prérequis](#-prérequis)
- [Installation](#-installation)
- [Configuration des agents](#-configuration-des-agents)
- [Règles de détection personnalisées](#-règles-de-détection-personnalisées)
- [Dashboards Kibana](#-dashboards-kibana)
- [Tests & validation](#-tests--validation)
- [Résultats & apprentissages](#-résultats--apprentissages)

---

## 🎯 Objectifs

Ce projet simule un SOC (Security Operations Center) minimaliste en environnement lab. Il m'a permis de :

- Comprendre la **corrélation de logs** multi-sources (Linux, Windows, pfSense)
- Mettre en pratique les concepts de **détection d'intrusion** (bruteforce, escalade de privilèges, scan réseau)
- Apprendre à **écrire des règles SIEM** adaptées à des scénarios d'attaque réels
- Automatiser les alertes et visualiser les événements de sécurité en temps réel

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     RÉSEAU LAB (192.168.10.0/24)            │
│                                                             │
│  ┌──────────────────┐        ┌─────────────────────────┐   │
│  │  Wazuh Manager   │◄──────►│   Elasticsearch + Kibana │   │
│  │  192.168.10.10   │        │     192.168.10.10        │   │
│  │  Ubuntu 22.04    │        │   (stack intégrée)       │   │
│  └────────┬─────────┘        └─────────────────────────┘   │
│           │                                                 │
│    ┌──────┼──────────────────────────────┐                  │
│    │      │          Agents Wazuh        │                  │
│    ▼      ▼                ▼             ▼                  │
│  ┌──────┐ ┌──────────┐ ┌──────────┐ ┌─────────┐           │
│  │Linux │ │ Windows  │ │ pfSense  │ │ Kali    │           │
│  │.20   │ │ AD .30   │ │ FW  .1   │ │(attaque)│           │
│  └──────┘ └──────────┘ └──────────┘ └─────────┘           │
└─────────────────────────────────────────────────────────────┘
```

| Composant | Rôle | IP |
|---|---|---|
| Wazuh Manager | Collecte & corrélation des alertes | 192.168.10.10 |
| Elasticsearch | Stockage et indexation des logs | 192.168.10.10 |
| Kibana | Visualisation & dashboards | 192.168.10.10:5601 |
| Agent Linux (Ubuntu) | Source de logs — serveur web simulé | 192.168.10.20 |
| Agent Windows (AD) | Source de logs — Active Directory | 192.168.10.30 |
| pfSense | Firewall / logs réseau | 192.168.10.1 |

---

## ⚙️ Prérequis

### Matériel minimal (testé sur Proxmox)
- **RAM :** 8 Go minimum (16 Go recommandé)
- **CPU :** 4 vCPU
- **Stockage :** 80 Go SSD

### Logiciels
```bash
# Versions utilisées dans ce lab
Wazuh Manager  : 4.7.x
Elasticsearch  : 7.17.x
Kibana         : 7.17.x
Ubuntu Server  : 22.04 LTS
```

---

## 🚀 Installation

### 1. Déploiement automatisé (recommandé)

```bash
git clone https://github.com/AMA972/siem-wazuh-lab.git
cd siem-wazuh-lab
chmod +x scripts/deploy-wazuh.sh
sudo ./scripts/deploy-wazuh.sh
```

### 2. Installation manuelle étape par étape

#### 2.1 — Mise à jour système & dépendances

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install curl apt-transport-https unzip wget gnupg -y
```

#### 2.2 — Installation Wazuh Manager

```bash
# Ajout du dépôt Wazuh
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | \
  gpg --no-default-keyring --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg \
  --import && chmod 644 /usr/share/keyrings/wazuh.gpg

echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] \
  https://packages.wazuh.com/4.x/apt/ stable main" | \
  sudo tee /etc/apt/sources.list.d/wazuh.list

sudo apt update
sudo apt install wazuh-manager -y
sudo systemctl enable --now wazuh-manager
```

#### 2.3 — Installation Elasticsearch

```bash
wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | \
  sudo gpg --dearmor -o /usr/share/keyrings/elasticsearch-keyring.gpg

echo "deb [signed-by=/usr/share/keyrings/elasticsearch-keyring.gpg] \
  https://artifacts.elastic.co/packages/7.x/apt stable main" | \
  sudo tee /etc/apt/sources.list.d/elastic-7.x.list

sudo apt update && sudo apt install elasticsearch -y

# Configuration minimale
sudo sed -i 's/#network.host: .*/network.host: 0.0.0.0/' /etc/elasticsearch/elasticsearch.yml
sudo sed -i 's/#discovery.seed_hosts: .*/discovery.type: single-node/' /etc/elasticsearch/elasticsearch.yml

sudo systemctl enable --now elasticsearch
```

#### 2.4 — Installation Kibana

```bash
sudo apt install kibana -y

sudo sed -i 's/#server.host: .*/server.host: "0.0.0.0"/' /etc/kibana/kibana.yml
sudo sed -i 's/#elasticsearch.hosts: .*/elasticsearch.hosts: ["http:\/\/localhost:9200"]/' \
  /etc/kibana/kibana.yml

sudo systemctl enable --now kibana
```

#### 2.5 — Intégration Wazuh → Elasticsearch

```bash
# Plugin Wazuh pour Kibana
sudo -u kibana /usr/share/kibana/bin/kibana-plugin install \
  https://packages.wazuh.com/4.x/ui/kibana/wazuh_kibana-4.7.0_7.17.13-1.zip

sudo systemctl restart kibana
```

---

## 🖥️ Configuration des agents

### Agent Linux (Ubuntu Server)

```bash
# Sur la machine agent
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | sudo apt-key add -
echo "deb https://packages.wazuh.com/4.x/apt/ stable main" | \
  sudo tee /etc/apt/sources.list.d/wazuh.list
sudo apt update && sudo apt install wazuh-agent -y

# Pointer vers le manager
sudo sed -i 's/MANAGER_IP/192.168.10.10/' /var/ossec/etc/ossec.conf
sudo systemctl enable --now wazuh-agent
```

### Agent Windows (via PowerShell — exécuter en admin)

```powershell
# Téléchargement et installation silencieuse
$url = "https://packages.wazuh.com/4.x/windows/wazuh-agent-4.7.0-1.msi"
Invoke-WebRequest -Uri $url -OutFile "wazuh-agent.msi"

msiexec /i wazuh-agent.msi /q WAZUH_MANAGER="192.168.10.10" `
  WAZUH_AGENT_NAME="WIN-AD-LAB"

NET START WazuhSvc
```

---

## 📐 Règles de détection personnalisées

Fichier : `configs/custom_rules.xml`

```xml
<!-- Règles personnalisées Ali ADOUM MAHAMAT — AMA972 -->
<!-- Détection bruteforce SSH -->
<group name="syslog,sshd,custom_ama972">

  <rule id="100001" level="10" frequency="5" timeframe="60">
    <if_matched_sid>5716</if_matched_sid>
    <description>Bruteforce SSH détecté — 5 tentatives en 60s</description>
    <mitre>
      <id>T1110.001</id>
    </mitre>
    <group>authentication_failures,bruteforce,</group>
  </rule>

  <rule id="100002" level="12">
    <if_sid>5715</if_sid>
    <match>sudo</match>
    <description>Élévation de privilèges via sudo détectée</description>
    <mitre>
      <id>T1548.003</id>
    </mitre>
    <group>privilege_escalation,</group>
  </rule>

  <rule id="100003" level="8" frequency="20" timeframe="30">
    <if_matched_sid>40101</if_matched_sid>
    <description>Scan réseau probable — trafic anormal (Nmap/Masscan)</description>
    <mitre>
      <id>T1046</id>
    </mitre>
    <group>network_scan,recon,</group>
  </rule>

  <rule id="100004" level="14">
    <if_sid>100001</if_sid>
    <match>root</match>
    <description>CRITIQUE — Bruteforce SSH ciblant root</description>
    <mitre>
      <id>T1110.001</id>
    </mitre>
    <group>authentication_failures,bruteforce,high_severity,</group>
  </rule>

</group>
```

---

## 📊 Dashboards Kibana

Dashboards configurés et exportables depuis `configs/kibana-dashboards.ndjson` :

| Dashboard | Description |
|---|---|
| `AMA972 - Security Overview` | Vue globale des alertes par sévérité |
| `AMA972 - Authentication Events` | Tentatives SSH, RDP, sudo |
| `AMA972 - Network Threats` | Scans, connexions suspectes |
| `AMA972 - Windows AD Events` | Logons, GPO, modifications comptes |

**Import rapide :**
```bash
curl -X POST "localhost:5601/api/saved_objects/_import" \
  -H "kbn-xsrf: true" \
  --form file=@configs/kibana-dashboards.ndjson
```

---

## 🧪 Tests & validation

### Scénario 1 — Bruteforce SSH simulé

```bash
# Depuis Kali Linux (192.168.10.100)
hydra -l root -P /usr/share/wordlists/rockyou.txt \
  192.168.10.20 ssh -t 4 -V

# Résultat attendu : alerte Wazuh rule 100001 déclenchée en < 60s
```

### Scénario 2 — Scan Nmap furtif

```bash
nmap -sS -T3 -p 1-1024 192.168.10.0/24
# Résultat attendu : alerte rule 100003 dans Kibana
```

### Scénario 3 — Élévation de privilèges

```bash
# Depuis agent Linux
sudo cat /etc/shadow
# Résultat attendu : alerte rule 100002 niveau 12
```

---

## 📈 Résultats & apprentissages

### Ce que j'ai appris concrètement

- La **corrélation de logs** n'est pas triviale : un vrai SOC génère des milliers d'événements/jour, le tuning des règles est essentiel pour éviter les faux positifs
- Wazuh utilise le framework **MITRE ATT&CK** nativement — j'ai cartographié mes règles sur les tactiques réelles d'attaquants
- L'**indexation Elasticsearch** nécessite un tuning fin (shards, ILM policies) dès que le volume de logs monte
- J'aurais dû anticiper les besoins en **RAM** : Elasticsearch seul consomme 4 Go avec des logs actifs

### Difficultés rencontrées

| Problème | Solution trouvée |
|---|---|
| Kibana ne démarre pas | Conflit port 5601 → `lsof -i :5601` |
| Agent Windows non visible | Firewall Windows bloquait port 1514 UDP |
| Trop de faux positifs | Tuning des règles via `<if_sid>` + seuils |
| Elasticsearch OOM | Limité heap à 2g dans `jvm.options` |

---

## 📁 Structure du projet

```
siem-wazuh-lab/
├── README.md
├── scripts/
│   ├── deploy-wazuh.sh          # Déploiement automatisé complet
│   ├── add-agent.sh             # Enregistrement d'un nouvel agent
│   └── check-health.sh          # Vérification état des services
├── configs/
│   ├── custom_rules.xml         # Règles de détection personnalisées
│   ├── ossec.conf               # Config Wazuh Manager
│   ├── elasticsearch.yml        # Config Elasticsearch
│   └── kibana-dashboards.ndjson # Export dashboards Kibana
├── docs/
│   ├── architecture.md          # Schéma réseau détaillé
│   ├── tuning-guide.md          # Guide de tuning des règles
│   └── incident-response.md     # Procédures de réponse
└── screenshots/
    ├── dashboard-overview.png
    ├── alert-bruteforce.png
    └── kibana-timeline.png
```

---

## 🔗 Ressources utilisées

- [Documentation officielle Wazuh](https://documentation.wazuh.com)
- [MITRE ATT&CK Framework](https://attack.mitre.org)
- [Elastic Stack Docs](https://www.elastic.co/guide)

---

<div align="center">

**Ali ADOUM MAHAMAT** · [@AMA972](https://github.com/AMA972) · Montpellier, France

*Projet réalisé dans le cadre d'une montée en compétences en cybersécurité — 2025*

</div>

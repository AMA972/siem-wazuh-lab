#!/usr/bin/env bash
# ============================================================
#  deploy-wazuh.sh
#  Déploiement automatisé Wazuh Manager + ELK Stack
#
#  Auteur  : Ali ADOUM MAHAMAT (@AMA972)
#  GitHub  : https://github.com/AMA972/siem-wazuh-lab
#  Version : 1.0.0
#  Date    : 2025-03-15
#  Testé   : Ubuntu Server 22.04 LTS
# ============================================================

set -euo pipefail

# ──────────────────────────────────────────────
# Couleurs & helpers
# ──────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

banner() {
  echo -e "${BOLD}"
  echo "╔══════════════════════════════════════════════════════════╗"
  echo "║          SIEM LAB — Wazuh + ELK Stack Deployer          ║"
  echo "║          Ali ADOUM MAHAMAT (@AMA972)                    ║"
  echo "║          github.com/AMA972/siem-wazuh-lab               ║"
  echo "╚══════════════════════════════════════════════════════════╝"
  echo -e "${NC}"
}

# ──────────────────────────────────────────────
# Vérifications préalables
# ──────────────────────────────────────────────
preflight_checks() {
  info "Vérification des prérequis..."

  [[ $EUID -eq 0 ]] || error "Ce script doit être exécuté en root (sudo ./deploy-wazuh.sh)"

  OS=$(lsb_release -si 2>/dev/null || echo "Unknown")
  [[ "$OS" == "Ubuntu" ]] || warn "Script optimisé pour Ubuntu — comportement non garanti sur $OS"

  RAM_MB=$(free -m | awk '/^Mem:/{print $2}')
  [[ $RAM_MB -ge 6144 ]] || warn "RAM disponible : ${RAM_MB}MB — 8GB recommandés pour éviter les OOM"

  DISK_FREE=$(df / --output=avail -m | tail -1)
  [[ $DISK_FREE -ge 20480 ]] || error "Espace disque insuffisant (${DISK_FREE}MB libres, 20GB requis)"

  success "Prérequis validés (RAM: ${RAM_MB}MB, Disque libre: ${DISK_FREE}MB)"
}

# ──────────────────────────────────────────────
# Dépendances système
# ──────────────────────────────────────────────
install_dependencies() {
  info "Installation des dépendances..."
  apt-get update -qq
  apt-get install -y -qq \
    curl \
    apt-transport-https \
    unzip \
    wget \
    gnupg \
    lsb-release \
    software-properties-common \
    net-tools
  success "Dépendances installées"
}

# ──────────────────────────────────────────────
# Wazuh Manager
# ──────────────────────────────────────────────
install_wazuh_manager() {
  info "Installation de Wazuh Manager..."

  curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH \
    | gpg --no-default-keyring \
          --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg \
          --import
  chmod 644 /usr/share/keyrings/wazuh.gpg

  echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] \
    https://packages.wazuh.com/4.x/apt/ stable main" \
    | tee /etc/apt/sources.list.d/wazuh.list > /dev/null

  apt-get update -qq
  apt-get install -y -qq wazuh-manager

  # Déploiement des règles personnalisées
  cp "$(dirname "$0")/../configs/custom_rules.xml" \
     /var/ossec/etc/rules/local_rules.xml 2>/dev/null || \
     warn "custom_rules.xml non trouvé — règles par défaut conservées"

  systemctl enable --now wazuh-manager
  success "Wazuh Manager actif → $(systemctl is-active wazuh-manager)"
}

# ──────────────────────────────────────────────
# Elasticsearch
# ──────────────────────────────────────────────
install_elasticsearch() {
  info "Installation d'Elasticsearch 7.x..."

  wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch \
    | gpg --dearmor -o /usr/share/keyrings/elasticsearch-keyring.gpg

  echo "deb [signed-by=/usr/share/keyrings/elasticsearch-keyring.gpg] \
    https://artifacts.elastic.co/packages/7.x/apt stable main" \
    | tee /etc/apt/sources.list.d/elastic-7.x.list > /dev/null

  apt-get update -qq
  apt-get install -y -qq elasticsearch

  # Configuration
  cat > /etc/elasticsearch/elasticsearch.yml << 'EOF'
# AMA972 - SIEM Lab config
cluster.name: siem-lab-ama972
node.name: wazuh-node-1
network.host: 0.0.0.0
discovery.type: single-node
xpack.security.enabled: false
path.data: /var/lib/elasticsearch
path.logs: /var/log/elasticsearch
EOF

  # Limiter la heap pour éviter OOM en lab
  sed -i 's/-Xms[0-9]*g/-Xms2g/' /etc/elasticsearch/jvm.options
  sed -i 's/-Xmx[0-9]*g/-Xmx2g/' /etc/elasticsearch/jvm.options

  systemctl enable --now elasticsearch

  # Attente que l'API soit disponible
  info "Attente du démarrage d'Elasticsearch..."
  for i in {1..30}; do
    curl -s "http://localhost:9200/_cluster/health" | grep -q '"status"' && break
    sleep 5
    [[ $i -eq 30 ]] && error "Elasticsearch ne répond pas après 150s"
  done

  success "Elasticsearch actif → $(curl -s http://localhost:9200/_cat/health?h=status)"
}

# ──────────────────────────────────────────────
# Kibana
# ──────────────────────────────────────────────
install_kibana() {
  info "Installation de Kibana..."

  apt-get install -y -qq kibana

  cat > /etc/kibana/kibana.yml << 'EOF'
# AMA972 - SIEM Lab config
server.host: "0.0.0.0"
server.name: "siem-lab-ama972"
elasticsearch.hosts: ["http://localhost:9200"]
EOF

  systemctl enable --now kibana
  success "Kibana actif sur http://$(hostname -I | awk '{print $1}'):5601"
}

# ──────────────────────────────────────────────
# Plugin Wazuh pour Kibana
# ──────────────────────────────────────────────
install_wazuh_plugin() {
  info "Installation du plugin Wazuh pour Kibana..."

  WAZUH_PLUGIN="https://packages.wazuh.com/4.x/ui/kibana/wazuh_kibana-4.7.0_7.17.13-1.zip"

  sudo -u kibana /usr/share/kibana/bin/kibana-plugin install "$WAZUH_PLUGIN" || \
    warn "Plugin non installé — vérifier compatibilité des versions"

  systemctl restart kibana
  success "Plugin Wazuh installé"
}

# ──────────────────────────────────────────────
# Index Wazuh dans Elasticsearch
# ──────────────────────────────────────────────
configure_wazuh_index() {
  info "Création du template d'index Wazuh..."

  curl -s -X PUT "http://localhost:9200/_template/wazuh" \
    -H "Content-Type: application/json" \
    -d '{
      "index_patterns": ["wazuh-alerts-*"],
      "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0,
        "index.refresh_interval": "5s"
      }
    }' > /dev/null

  success "Template wazuh-alerts créé"
}

# ──────────────────────────────────────────────
# Rapport final
# ──────────────────────────────────────────────
final_report() {
  LOCAL_IP=$(hostname -I | awk '{print $1}')

  echo ""
  echo -e "${GREEN}${BOLD}════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}${BOLD}  ✅  Déploiement terminé avec succès !          ${NC}"
  echo -e "${GREEN}${BOLD}════════════════════════════════════════════════${NC}"
  echo ""
  echo -e "  ${BOLD}Services actifs :${NC}"
  echo -e "  • Wazuh Manager   → $(systemctl is-active wazuh-manager)"
  echo -e "  • Elasticsearch   → $(systemctl is-active elasticsearch)"
  echo -e "  • Kibana          → $(systemctl is-active kibana)"
  echo ""
  echo -e "  ${BOLD}Accès :${NC}"
  echo -e "  • Kibana (SIEM)   → http://${LOCAL_IP}:5601"
  echo -e "  • Elasticsearch   → http://${LOCAL_IP}:9200"
  echo -e "  • Logs Wazuh      → /var/ossec/logs/alerts/alerts.log"
  echo ""
  echo -e "  ${BOLD}Prochaines étapes :${NC}"
  echo -e "  1. Ouvrir Kibana → Wazuh App → ajouter vos agents"
  echo -e "  2. Importer les dashboards : configs/kibana-dashboards.ndjson"
  echo -e "  3. Déployer les agents : scripts/add-agent.sh <IP>"
  echo ""
  echo -e "  Auteur : Ali ADOUM MAHAMAT (@AMA972)"
  echo -e "  Repo   : github.com/AMA972/siem-wazuh-lab"
  echo ""
}

# ──────────────────────────────────────────────
# Point d'entrée principal
# ──────────────────────────────────────────────
main() {
  banner
  preflight_checks
  install_dependencies
  install_wazuh_manager
  install_elasticsearch
  install_kibana
  install_wazuh_plugin
  configure_wazuh_index
  final_report
}

main "$@"

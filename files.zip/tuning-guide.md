# Guide de tuning des règles Wazuh

> Auteur : Ali ADOUM MAHAMAT (@AMA972)

## Le problème des faux positifs

Quand j'ai lancé le SIEM pour la première fois, j'ai reçu des centaines d'alertes niveau 7+ par heure — la majorité étaient des faux positifs (cron jobs, healthchecks, scans légitimes internes).

Voici comment j'ai réduit le bruit à moins de 20 alertes/heure pertinentes.

## Identifier les faux positifs

```bash
# Top 10 des règles les plus déclenchées
grep "Rule:" /var/ossec/logs/alerts/alerts.log | \
  awk '{print $2}' | sort | uniq -c | sort -rn | head 10

# Alertes par IP source
grep "srcip" /var/ossec/logs/alerts/alerts.log | \
  awk -F'"' '{print $4}' | sort | uniq -c | sort -rn | head 10
```

## Techniques de tuning

### 1. Whitelister des IPs légitimes

```xml
<!-- Dans ossec.conf, section <global> -->
<white_list>192.168.10.1</white_list>   <!-- pfSense -->
<white_list>192.168.10.10</white_list>  <!-- Manager lui-même -->
```

### 2. Augmenter les seuils de fréquence

```xml
<!-- Avant : 3 tentatives en 60s -->
<rule id="100001" level="10" frequency="3" timeframe="60">

<!-- Après tuning : 8 tentatives en 60s (réduit le bruit) -->
<rule id="100001" level="10" frequency="8" timeframe="60">
```

### 3. Ignorer certains patterns

```xml
<rule id="100099" level="0">
  <if_sid>5716</if_sid>
  <match>sshd.*nagios|monitoring-agent|zabbix</match>
  <description>Ignore — monitoring SSH légal</description>
</rule>
```

### 4. Différencier par horaire

Les alertes à 3h du matin méritent plus d'attention qu'à 14h :

```xml
<rule id="100022" level="13">
  <if_sid>100020</if_sid>
  <time>22:00 - 07:00</time>
  <description>Activité réseau nocturne — priorité haute</description>
</rule>
```

## Résultats après tuning

| Période | Alertes/heure | Faux positifs |
|---|---|---|
| Avant tuning | ~400 | ~95% |
| Après 1 semaine | ~50 | ~60% |
| Après 1 mois | ~18 | ~15% |

**Leçon :** Le tuning d'un SIEM est un processus continu. Un bon analyste passe autant de temps à affiner les règles qu'à analyser les alertes.

---

*Ali ADOUM MAHAMAT — @AMA972*

# Architecture — SIEM Lab Wazuh + ELK

> Auteur : Ali ADOUM MAHAMAT (@AMA972) | Montpellier, France

## Vue d'ensemble

Ce document décrit les choix d'architecture du lab SIEM et les décisions techniques prises lors de sa mise en place.

## Pourquoi Wazuh ?

J'ai comparé plusieurs solutions open source avant de choisir Wazuh :

| Critère | Wazuh | Graylog | Security Onion |
|---|---|---|---|
| Intégration MITRE ATT&CK | ✅ Native | ❌ Manuelle | ✅ Partielle |
| Facilité de déploiement | ✅ | ⚠️ Complexe | ❌ Lourd |
| Agents multi-OS | ✅ Win/Linux/Mac | ⚠️ Syslog only | ✅ |
| Communauté active | ✅ | ✅ | ✅ |
| Ressources requises | Moyen | Faible | Lourd |

**Conclusion :** Wazuh offre l'intégration MITRE ATT&CK native et les agents multi-OS, ce qui correspond exactement à un contexte SOC.

## Flux de données

```
Endpoints (agents)
     │
     │  ossec-logcollector (port 1514 UDP/TCP)
     ▼
Wazuh Manager
  ├── Analyse des règles (XML)
  ├── Décodeurs (decoder.xml)
  ├── Corrélation temporelle
  └── Génération d'alertes
     │
     │  Filebeat → port 9200
     ▼
Elasticsearch
  ├── Index: wazuh-alerts-YYYY.MM.DD
  ├── Index: wazuh-monitoring-*
  └── Rétention: 30 jours (ILM policy)
     │
     ▼
Kibana + Plugin Wazuh
  ├── Dashboard Overview
  ├── Security Events
  └── Compliance (PCI-DSS, GDPR)
```

## Choix réseau

J'ai utilisé un réseau `192.168.10.0/24` isolé sous Proxmox avec :

- **VLAN 10** — Management (Wazuh Manager, ELK)
- **VLAN 20** — Serveurs (agents Linux)
- **VLAN 30** — Windows (AD, poste client)
- **VLAN 99** — Kali Linux (attaquant simulé)

Le pfSense contrôle les flux inter-VLAN — les agents ne peuvent joindre que le Manager sur le port 1514.

## Dimensionnement

Pour un lab avec 4-5 sources de logs et une charge modérée :

| Composant | CPU | RAM | Disque |
|---|---|---|---|
| Wazuh Manager | 2 vCPU | 2 GB | 20 GB |
| Elasticsearch | 2 vCPU | 4 GB | 40 GB |
| Kibana | 1 vCPU | 1 GB | 10 GB |
| **Total** | **5 vCPU** | **7 GB** | **70 GB** |

## Décisions de configuration

### Heap Elasticsearch
Limité à 2 GB (au lieu des 4 GB par défaut) car le lab tourne sur une machine physique de 16 GB partagée avec les VMs agents. En production, la règle est de ne jamais dépasser 50% de la RAM disponible.

### Rétention des logs
ILM policy configurée pour 30 jours — compromis entre utilité forensique et espace disque. Un vrai SOC garderait 90 jours minimum selon les standards ISO 27001.

### Pas de TLS en lab
Le chiffrement entre agents et Manager est désactivé pour simplifier le lab. **En production, c'est une mauvaise pratique** — Wazuh supporte TLS mutuel nativement.

---

*Ali ADOUM MAHAMAT — @AMA972 — github.com/AMA972/siem-wazuh-lab*
